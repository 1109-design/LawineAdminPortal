import React from "react";
import { StyleSheet, Text, View, Switch, TouchableOpacity } from "react-native";

const Settings = () => {
  const [autoInstall, setAutoInstall] = React.useState(false);

  const handleAutoInstallToggle = () => {
    setAutoInstall(!autoInstall);
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.section}
        onPress={() => console.log("help and feedback clicked")}
      >
        <Text style={styles.sectionTitle}>Help and Feedback</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.section}
        onPress={() => console.log("check for new version clicked")}
      >
        <Text style={styles.sectionTitle}>Check for New Version</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.section}
        onPress={() => console.log("like us on facebook clicked")}
      >
        <Text style={styles.sectionTitle}>Like Us on Facebook</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.section}
        onPress={() => console.log("about clicked")}
      >
        <Text style={styles.sectionTitle}>About</Text>
      </TouchableOpacity>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Sync once internet is on</Text>
        <Switch
          value={autoInstall}
          onValueChange={handleAutoInstallToggle}
          style={styles.autoInstallSwitch}
          trackColor={{ false: "#767577", true: "#81b0ff" }}
          thumbColor={autoInstall ? "#f5dd4b" : "#f4f3f4"}
          ios_backgroundColor="#3e3e3e"
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  section: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: "#e0e0e0",
    paddingVertical: 10,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#3f51b5",
  },
  autoInstallSwitch: {
    transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }],
  },
});

export default Settings;
